"""Unified engine acceptance tests. Toy scenes are SYNTHETIC, not field observations."""
from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from ai_inference import ENHANCED_MODEL_FEATURES, feature_frame
from decision_engine import (UrbanRayDecisionEngine, screen_buildings,
                             rank_wall_hotspots)


class ToyModel:
    def __init__(self, value): self.value=value
    def predict(self, x):return np.full(len(x),self.value,dtype=float)


def toy_engine(reg=2., hot=8.):
    common={'features':list(ENHANCED_MODEL_FEATURES),
        'target':'multibounce_abs_Wm2','prediction_mode':'residual',
        'source_hash':'same-physics-archive'}
    return UrbanRayDecisionEngine(
        dict(common,model=ToyModel(reg),model_role='regression',target_transform='none'),
        dict(common,model=ToyModel(np.log1p(hot)),model_role='hotspot',target_transform='log1p'),
        disagreement_review_threshold_Wm2=5.)


def tiny_scene():
    return {'area':np.array([10.,10.,12.,12.]),
            'center':np.array([[0,0,15],[20,0,15],[5,5,5],[25,5,5]],dtype=float),
            'normal':np.array([[0,0,1],[0,0,1],[1,0,0],[-1,0,0]]),
            'kind':np.array(['roof','roof','wall','wall']),
            'building_id':np.array(['a','b','a','b'])}


def frame_for_engine():
    sc=tiny_scene();src=np.array([800.,700.,500.,400.])
    sky=np.ones(4)*.8
    alpha=np.array([.18,.18,.25,.25])
    weather={'direct_normal_irradiance_instant':520.,
             'diffuse_radiation_instant':110.,
             'temperature_2m':24.,'wind_speed_10m':4.}
    frame=feature_frame(sc,src,sky,[.4,.4,.8246],weather,alpha,include_geometry=True)
    return frame,src,sc


def test_dual_models_keep_distinct_task_outputs_on_identical_features():
    f,s,sc=frame_for_engine()
    est=toy_engine().predict_frame(f,s,sc['area'])
    floor=f.direct_plus_sky_abs_Wm2.to_numpy()
    np.testing.assert_allclose(est.radiation.flux_Wm2,floor+2.)
    np.testing.assert_allclose(est.hotspots.flux_Wm2,floor+8.)
    np.testing.assert_allclose(est.model_disagreement_Wm2,np.full(4,6.))
    assert est.review_mask.all() and est.metadata['feature_frame_shared']
    assert not est.metadata['uncertainty_is_calibrated']
    assert not est.metadata['field_cooling_accuracy_established']


def test_night_zero_source_both_specialists_and_zero_disagreement():
    f,s,sc=frame_for_engine()
    est=toy_engine().predict_frame(f,np.zeros_like(s),sc['area'])
    assert np.all(est.radiation.flux_Wm2==0)
    assert np.all(est.hotspots.flux_Wm2==0)
    assert not est.review_mask.any()


def test_fail_closed_on_changed_model_provenance_role_or_albedo():
    eng=toy_engine()
    f,s,sc=frame_for_engine()
    bad=f.copy();bad.loc[0,'albedo_assumed']=.4
    with pytest.raises(ValueError,match='outside trained'):
        eng.predict_frame(bad,s,sc['area'])
    with pytest.raises(ValueError,match='exact geometry-aware'):
        eng.predict_frame(f.drop(columns=['neighbor_buildings_100m']),s,sc['area'])
    bogus=toy_engine().hotspot.copy();bogus['source_hash']='other-date'
    with pytest.raises(ValueError,match='provenance'):
        UrbanRayDecisionEngine(eng.regression,bogus)
    bogus=eng.hotspot.copy();bogus['model_role']='regression'
    with pytest.raises(ValueError,match='hotspot'):
        UrbanRayDecisionEngine(eng.regression,bogus)


def sample_day():
    sc=tiny_scene()
    rows=[]
    for scenario in ('dark_roof','reflective_roof'):
        for hour in range(24):
            for fid in range(4):
                roof=fid<2
                base=100. if roof else 20.
                regression=(150. if scenario=='dark_roof' else 50.) if roof else 25.
                specialist=(152. if scenario=='dark_roof' else 53.) if roof else (30. if scenario=='dark_roof' else 60.)
                rows.append(dict(face_id=fid,time_utc=f'2025-06-23T{hour:02d}:00:00Z',
                    scenario=scenario,building_id=sc['building_id'][fid],kind=sc['kind'][fid],
                    area_m2=sc['area'][fid],ai_abs_Wm2=regression,
                    hotspot_abs_Wm2=specialist,baseline_abs_Wm2=base))
    return pd.DataFrame(rows),sc


def test_counterfactuals_are_matched_and_neighbor_effect_not_causal():
    d,sc=sample_day()
    result,meta=screen_buildings(d,sc,wall_radius_m=90.)
    assert len(result)==2 and set(result.building_id)=={'a','b'}
    assert set(result.neighbor_wall_count)=={1}
    assert set(result.review_status).issubset({'PRIORITY · CHECK FACADES','REVIEW NEIGHBOR FACADES'})
    assert result.roof_solar_heat_avoided_kWh_simulated_day.to_numpy()==pytest.approx([24.,24.])
    assert result.roof_model_spread_kWh_simulated_day.to_numpy()==pytest.approx([.24,.24])
    assert result.nearby_wall_reflection_change_kWh_all_roofs_reflective.to_numpy()==pytest.approx([8.64,8.64])
    assert meta['neighbor_wall_change_is_individual_roof_causal_effect'] is False
    assert meta['model_disagreement_not_calibrated_uncertainty'] is True
    assert meta['new_independent_real_world_validation'] is False


def test_missing_or_mismatched_input_is_rejected():
    d,sc=sample_day()
    with pytest.raises(ValueError,match='complete, matched'):
        screen_buildings(d[d.time_utc!='2025-06-23T20:00:00Z'],sc)
    with pytest.raises(ValueError,match='every face'):
        screen_buildings(d.iloc[:-1],sc)
    tampered=d.copy()
    tampered.loc[0,'building_id']='wrong'
    with pytest.raises(ValueError,match='geometry|Face attributes'):
        screen_buildings(tampered,sc)
    with pytest.raises(ValueError,match='Both roof'):
        screen_buildings(d[d.scenario=='dark_roof'],sc)


def test_specialist_picks_top_wall_without_peeking_at_physics():
    d,sc=sample_day()
    d.loc[(d.face_id==3)&(d.scenario=='dark_roof'),'hotspot_abs_Wm2']=100.
    hot=rank_wall_hotspots(d,top_k=2)
    assert hot.face_id.tolist()==[3,2]
    assert 'physics_abs_Wm2' not in d.columns
    assert hot.predicted_reflection_Wh_per_m2_day.iloc[0]==pytest.approx(1920.)


def test_original_model_weights_are_untouched_by_unified_engine():
    reg=ROOT/'outputs/geometry_ai_upgrade/regression_surrogate.joblib'
    hot=ROOT/'outputs/geometry_ai_upgrade/hotspot_surrogate.joblib'
    for p in (reg,hot):assert p.exists()
    hash_before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (reg,hot)}
    loaded=UrbanRayDecisionEngine.from_paths(reg,hot)
    assert loaded.regression['model_role']=='regression'
    assert loaded.hotspot['model_role']=='hotspot'
    assert hash_before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (reg,hot)}


def test_unified_dashboard_contains_genuine_dual_model_outputs():
    html=ROOT/'outputs/unified_decision_engine/dashboard/UrbanRay_AI_Explorer_OFFLINE.html'
    if not html.exists():pytest.skip('Dashboard not built yet')
    content=html.read_text()
    data=json.JSONDecoder().raw_decode(content[content.index('const D=')+len('const D='):])[0]
    u=data['unified_engine']
    assert len(u['screenings'])==88
    assert len(u['top_hotspots'])==20
    assert u['model_weights_modified'] is False
    assert u['validated_against_field_measurements'] is False
    assert u['wall_scenario_change_is_individual_roof_causal_effect'] is False
    assert len(set(b['building_id'] for b in u['screenings']))==88
    assert 'renderUnifiedDecision()' in content
    assert 'unifiedDecision' in content
