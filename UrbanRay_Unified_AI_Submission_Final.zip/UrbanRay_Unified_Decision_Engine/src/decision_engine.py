"""UrbanRay's single decision API around two *unchanged* specialist models.

The regression surrogate supplies radiation values; the separately trained
hotspot surrogate supplies reflection-hotspot rankings. Neither is retrained or
blended in this module. Both reuse the *same* prediction-time feature frame.

All resulting quantities are simulator-relative. Difference between models is
an uncalibrated disagreement *diagnostic*, not a confidence interval, field
validation, or proof of physical safety. 'Priority' means a research screening
candidate, NOT a recommendation to install materials.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from ai_inference import (ENHANCED_MODEL_FEATURES, ShortwaveEstimate,
                          feature_frame, load_surrogate, predict_from_frame)
from geometry_features import GeometryGraph, build_geometry_graph

DEFAULT_ENGINE_MODELS = (
    'outputs/geometry_ai_upgrade/regression_surrogate.joblib',
    'outputs/geometry_ai_upgrade/hotspot_surrogate.joblib',
)


@dataclass(frozen=True)
class DecisionEstimate:
    radiation: ShortwaveEstimate
    hotspots: ShortwaveEstimate
    model_disagreement_Wm2: np.ndarray
    review_mask: np.ndarray
    metadata: dict[str, Any]


class UrbanRayDecisionEngine:
    """One fail-closed prediction interface retaining two separately trained models."""

    def __init__(self, regression_bundle: dict, hotspot_bundle: dict,
                 *, disagreement_review_threshold_Wm2: float = 15.):
        for role, b in [('regression', regression_bundle), ('hotspot', hotspot_bundle)]:
            if b.get('model_role') != role:
                raise ValueError(f'Expected an independently trained {role} model.')
            if list(b.get('features', [])) != list(ENHANCED_MODEL_FEATURES):
                raise ValueError(f'{role} must use the shared geometry feature schema.')
            if b.get('target') != 'multibounce_abs_Wm2' or b.get('prediction_mode') != 'residual':
                raise ValueError(f'{role} has an incompatible prediction target or mode.')
        if regression_bundle.get('source_hash') != hotspot_bundle.get('source_hash') or not regression_bundle.get('source_hash'):
            raise ValueError('The two models must share the same training dataset provenance.')
        if not np.isfinite(disagreement_review_threshold_Wm2) or disagreement_review_threshold_Wm2 <= 0:
            raise ValueError('Review threshold must be a positive finite W/m2 value.')
        self.regression = regression_bundle
        self.hotspot = hotspot_bundle
        self.threshold = float(disagreement_review_threshold_Wm2)

    @classmethod
    def from_paths(cls, regression_path: str | Path, hotspot_path: str | Path,
                   **kwargs) -> 'UrbanRayDecisionEngine':
        return cls(load_surrogate(regression_path), load_surrogate(hotspot_path), **kwargs)

    def predict_frame(self, frame: pd.DataFrame, source_W: np.ndarray,
                      area_m2: np.ndarray) -> DecisionEstimate:
        """Run both learned specialists on the same physically derived feature frame."""
        required = list(ENHANCED_MODEL_FEATURES)
        if list(frame.columns) != required:
            raise ValueError('Decision engine requires exact geometry-aware features and order.')
        if not np.isfinite(frame.to_numpy(dtype=float)).all():
            raise ValueError('Nonfinite decision inputs.')
        # Roof training examples used ONLY the two documented albedos. Do not
        # silently extrapolate to arbitrary retrofit products/materials.
        roof = frame.kind_code.to_numpy() == 0
        roof_albedo = frame.albedo_assumed.to_numpy(dtype=float)[roof]
        if roof_albedo.size and not np.isclose(roof_albedo[:, None], [0.18, 0.58], atol=1e-6).any(axis=1).all():
            raise ValueError('Roof albedo outside trained (.18/.58) scenarios; abstaining.')
        r = predict_from_frame(self.regression, frame, source_W, area_m2)
        h = predict_from_frame(self.hotspot, frame, source_W, area_m2)
        difference = np.abs(r.flux_Wm2 - h.flux_Wm2)
        review = difference > self.threshold
        if r.metadata['source_cap_applied'] or h.metadata['source_cap_applied']:
            # Uncertain when the physical guard had to rescale an output.
            review = np.ones(len(frame), dtype=bool)
        return DecisionEstimate(
            radiation=r,
            hotspots=h,
            model_disagreement_Wm2=difference,
            review_mask=review,
            metadata={
                'system': 'UrbanRay unified decision engine v1',
                'radiation_model_role': 'geometry-aware regression (unchanged model)',
                'hotspot_model_role': 'reflection specialist (unchanged model)',
                'feature_frame_shared': True,
                'model_disagreement_review_threshold_Wm2': self.threshold,
                'faces_flagged_for_review': int(review.sum()),
                'faces_evaluated': len(frame),
                'source_cap_applied_either': bool(r.metadata['source_cap_applied'] or h.metadata['source_cap_applied']),
                'uncertainty_is_calibrated': False,
                'model_disagreement_is_uncertainty_interval': False,
                'physical_hotspot_labels_observed': False,
                'field_cooling_accuracy_established': False,
                'source_data_kind': 'simulator-based radiation labels',
            })

    def predict_scene(self, scene: dict, source_W: np.ndarray, sky: np.ndarray,
                      sun: np.ndarray, weather_row: Any, albedo_by_face: np.ndarray,
                      geometry_graph: GeometryGraph | None = None) -> DecisionEstimate:
        graph = geometry_graph if geometry_graph is not None else build_geometry_graph(scene)
        features = feature_frame(scene, source_W, sky, sun, weather_row, albedo_by_face,
                                 geometry_graph=graph, include_geometry=True)
        return self.predict_frame(features, source_W, scene['area'])


def screen_buildings(day: pd.DataFrame, scene: dict, *, wall_radius_m: float = 75.,
                     model_spread_fraction: float = 0.25) -> tuple[pd.DataFrame, dict]:
    """Two-model deterministic, non-causal screening of a complete two-scenario day.

    Each roof's reduction is under the *all roofs changed* counterfactual; the
    nearest wall change is ALSO from changing all roofs, not from changing that
    particular roof. The outputs are context and review flags, never causal
    per-building wall penalties or a single unprincipled aggregate utility.
    """
    required = {'face_id','time_utc','scenario','building_id','kind','area_m2',
                'ai_abs_Wm2','hotspot_abs_Wm2','baseline_abs_Wm2'}
    if not required.issubset(day):
        raise ValueError(f'Decision day is missing columns: {sorted(required-set(day.columns))}')
    if not (np.isfinite(wall_radius_m) and wall_radius_m > 0 and
            np.isfinite(model_spread_fraction) and model_spread_fraction > 0):
        raise ValueError('Review parameters must be positive and finite.')
    d = day.copy()
    if d.duplicated(['scenario','time_utc','face_id']).any():
        raise ValueError('Duplicate scenario/hour/face keys.')
    if set(d.scenario.unique()) != {'dark_roof','reflective_roof'}:
        raise ValueError('Both roof counterfactual scenarios are required.')
    times = sorted(d.time_utc.unique())
    if len(times) != 24:
        raise ValueError('Require a complete, matched 24-hour comparison.')
    parsed = pd.to_datetime(times,utc=True,errors='coerce')
    if parsed.isna().any() or not (pd.Series(parsed).diff().dropna()==pd.Timedelta(hours=1)).all():
        raise ValueError('Require 24 actual consecutive UTC hours, not merely 24 labels.')
    n = len(scene['area'])
    for (_, _), frame in d.groupby(['scenario','time_utc']):
        if len(frame) != n or not np.array_equal(np.sort(frame.face_id.to_numpy()),np.arange(n)):
            raise ValueError('Counterfactual must include every face for every hour.')
    for name in ('ai_abs_Wm2','hotspot_abs_Wm2','baseline_abs_Wm2','area_m2'):
        if not np.isfinite(d[name].to_numpy(float)).all():
            raise ValueError(f'Nonfinite {name} in complete day.')
    if (d.area_m2 <= 0).any() or (d[['ai_abs_Wm2','hotspot_abs_Wm2','baseline_abs_Wm2']] < -1e-8).any().any():
        raise ValueError('Nonphysical absorbed radiation or patch area.')
    first=d[(d.scenario=='dark_roof')&(d.time_utc==times[0])].sort_values('face_id')
    if (not np.allclose(first.area_m2.to_numpy(),scene['area'],rtol=1e-6,atol=1e-6)
        or not np.array_equal(first.building_id.astype(str).to_numpy(),np.asarray(scene['building_id']).astype(str))
        or not np.array_equal(first.kind.to_numpy(),scene['kind'])):
        raise ValueError('Input face geometry does not match verified scene.')
    # No time-varying/mismatched face annotations allowed in either scenario.
    annotations=d.merge(first[['face_id','building_id','kind','area_m2']],on='face_id',
                        suffixes=('','_expected'),validate='many_to_one')
    if (not (annotations.building_id.astype(str)==annotations.building_id_expected.astype(str)).all()
        or not (annotations.kind==annotations.kind_expected).all()
        or not np.allclose(annotations.area_m2,annotations.area_m2_expected,rtol=1e-6,atol=1e-6)):
        raise ValueError('Face attributes differ across scenarios or hours.')
    # Sum W/m2 * m2 * 1 hour / 1000 => kWh of modeled incident/absorbed
    # solar energy. This is NOT electric kWh or measured air temperature.
    for col in ('ai_abs_Wm2','hotspot_abs_Wm2','baseline_abs_Wm2'):
        d[col+'_kWh'] = d[col]*d.area_m2/1000.
    compact = d.groupby(['face_id','scenario'],sort=True)[
        [col+'_kWh' for col in ('ai_abs_Wm2','hotspot_abs_Wm2','baseline_abs_Wm2')]
    ].sum().unstack('scenario')
    coords=np.asarray(scene['center'],dtype=float)
    ids=np.asarray(scene['building_id']).astype(str)
    kind=np.asarray(scene['kind'])
    area=np.asarray(scene['area'],dtype=float)
    roofs=kind=='roof'
    walls=kind=='wall'
    candidates=sorted(set(ids[roofs]))
    result=[]
    for bid in candidates:
        ri=np.flatnonzero(roofs & (ids==bid))
        if not len(ri):continue
        footprint_center=np.average(coords[ri,:2],axis=0,weights=area[ri])
        nearby=np.flatnonzero(walls & (ids!=bid) &
                   (np.linalg.norm(coords[:,:2]-footprint_center,axis=1)<=wall_radius_m))
        reg_gain=float((compact[('ai_abs_Wm2_kWh','dark_roof')].loc[ri] -
                        compact[('ai_abs_Wm2_kWh','reflective_roof')].loc[ri]).sum())
        hot_gain=float((compact[('hotspot_abs_Wm2_kWh','dark_roof')].loc[ri] -
                        compact[('hotspot_abs_Wm2_kWh','reflective_roof')].loc[ri]).sum())
        spread=abs(reg_gain-hot_gain)
        if len(nearby):
            # Extra absorbed wall shortwave, with direct+sky removed, under
            # WHOLE-NEIGHBORHOOD roof scenarios. Not per-roof attribution.
            h=compact['hotspot_abs_Wm2_kWh'];base=compact['baseline_abs_Wm2_kWh']
            wall_change=float(((h['reflective_roof']-base['reflective_roof']) -
                               (h['dark_roof']-base['dark_roof'])).loc[nearby].sum())
        else: wall_change=None
        result.append({'building_id':bid,
            'roof_area_m2':float(area[ri].sum()),
            'roof_solar_heat_avoided_kWh_simulated_day':reg_gain,
            'roof_hotspot_model_comparator_kWh_simulated_day':hot_gain,
            'roof_model_spread_kWh_simulated_day':spread,
            'relative_roof_model_spread':spread/max(1.,abs(reg_gain)),
            'neighbor_wall_count':int(len(nearby)),
            'nearby_wall_reflection_change_kWh_all_roofs_reflective':wall_change,
            'nearby_wall_radius_m':wall_radius_m})
    out=pd.DataFrame(result)
    if out.empty:raise ValueError('No eligible roof buildings in scene.')
    high_cutoff=float(out.roof_solar_heat_avoided_kWh_simulated_day.quantile(.75))
    out['roof_gain_top_quartile'] = out.roof_solar_heat_avoided_kWh_simulated_day >= high_cutoff
    out['models_disagree_on_roof_gain'] = out.relative_roof_model_spread > model_spread_fraction
    out['neighbor_reflection_increase_flag'] = out.nearby_wall_reflection_change_kWh_all_roofs_reflective.fillna(0.) > .01
    out['review_status'] = np.select(
        [out.neighbor_wall_count == 0,
         out.models_disagree_on_roof_gain,
         out.neighbor_reflection_increase_flag & out.roof_gain_top_quartile &
             (out.roof_solar_heat_avoided_kWh_simulated_day>0),
         out.neighbor_reflection_increase_flag,
         out.roof_gain_top_quartile & (out.roof_solar_heat_avoided_kWh_simulated_day>0)],
        ['NO NEIGHBOR WALL COVERAGE','REVIEW MODEL DISAGREEMENT',
         'PRIORITY · CHECK FACADES','REVIEW NEIGHBOR FACADES',
         'PRIORITIZE FOR FURTHER STUDY'],
        default='PRELIMINARY SCREEN ONLY')
    out=out.sort_values(['roof_solar_heat_avoided_kWh_simulated_day','building_id'],
                        ascending=[False,True]).reset_index(drop=True)
    out.insert(0,'screen_rank',np.arange(1,len(out)+1))
    summary={'engine':'two trained, unchanged model specialists / one decision API',
        'radiation_role':'regression','hotspot_role':'hotspot specialist',
        'time_hours':len(times),'building_count':len(out),
        'wall_radius_m':wall_radius_m,
        'high_priority_threshold_kWh':high_cutoff,
        'review_model_spread_fraction':model_spread_fraction,
        'review_wall_delta_threshold_kWh':.01,
        'decision_safety':'screening/review only; never automatic roofing approval',
        'neighbor_wall_change_is_individual_roof_causal_effect':False,
        'neighbor_wall_change_is_whole_neighborhood_scenario':True,
        'screen_rank_not_optimized_tradeoff_utility':True,
        'model_disagreement_not_calibrated_uncertainty':True,
        'new_independent_real_world_validation':False,
        'units':'kWh of modeled absorbed solar energy per day (not electrical savings)',
    }
    return out,summary


def rank_wall_hotspots(day: pd.DataFrame, *, top_k: int = 20) -> pd.DataFrame:
    """Select modeled reflection hotspots; never use simulator target to rank."""
    required={'face_id','time_utc','scenario','kind','building_id',
              'hotspot_abs_Wm2','ai_abs_Wm2','baseline_abs_Wm2'}
    if not required.issubset(day):raise ValueError('Missing hotspot prediction fields.')
    walls=day[(day.kind=='wall')&(day.scenario=='dark_roof')].copy()
    if walls.empty or walls.duplicated(['face_id','time_utc']).any():
        raise ValueError('Missing or duplicate wall samples.')
    daily=walls.groupby('face_id').agg(
        building_id=('building_id','first'),
        hours=('time_utc','nunique'),
        hotspot_abs_Wm2_hour_sum=('hotspot_abs_Wm2','sum'),
        regression_abs_Wm2_hour_sum=('ai_abs_Wm2','sum'),
        base_Wm2_hour_sum=('baseline_abs_Wm2','sum'))
    if not (daily.hours==24).all():raise ValueError('Hotspots require complete 24-hour samples.')
    daily['predicted_reflection_Wh_per_m2_day']=(daily.hotspot_abs_Wm2_hour_sum-daily.base_Wm2_hour_sum).clip(lower=0.)
    daily['model_spread_Wh_per_m2_day']=(daily.hotspot_abs_Wm2_hour_sum-daily.regression_abs_Wm2_hour_sum).abs()
    daily=daily.sort_values(['predicted_reflection_Wh_per_m2_day'],ascending=False,kind='stable')
    if not isinstance(top_k,int) or top_k<1:raise ValueError('top_k must be positive integer')
    return daily.head(top_k).reset_index()[['face_id','building_id',
          'predicted_reflection_Wh_per_m2_day','model_spread_Wh_per_m2_day']]
