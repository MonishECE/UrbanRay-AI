"""AI upgrade tests use toy numerical data only, not environmental observations."""
from __future__ import annotations
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from ai_inference import (MODEL_FEATURES,feature_frame,predict_from_frame,
                          load_surrogate)

class FixedModel:
    def __init__(self,value):self.value=float(value)
    def predict(self,x):return np.full(len(x),self.value)


def toy_scene():
    return {'area':np.array([2.,1.]),
            'center':np.array([[1.,2.,10.],[2.,3.,0.]]),
            'kind':np.array(['roof','ground']),
            'normal':np.array([[0,0,1],[0,0,1]])}


def toy_frame():
    w={'direct_normal_irradiance_instant':200.,'diffuse_radiation_instant':40.,
       'temperature_2m':26.,'wind_speed_10m':4.}
    scene=toy_scene();src=np.array([400.,100.]); alpha=np.array([.18,.12])
    frame=feature_frame(scene,src,np.array([.8,.8]),np.array([0.,.7,.7]),w,alpha)
    return frame,src,scene['area']


def test_feature_schema_matches_trainer():
    from train_surrogate import PHYSICS
    f,_,_=toy_frame()
    assert f.columns.tolist()==list(MODEL_FEATURES)==PHYSICS
    assert f.direct_plus_sky_abs_Wm2.to_numpy()==pytest.approx([164.,88.])
    assert f.kind_code.tolist()==[0,2]


def test_residual_surrogate_predicts_only_extra_reflection_and_source_cap():
    f,s,a=toy_frame()
    bundle={'model':FixedModel(10.),'prediction_mode':'residual'}
    p=predict_from_frame(bundle,f,s,a)
    assert p.flux_Wm2==pytest.approx([174.,98.])
    assert p.metadata['energy_balance_verified'] is False
    high={'model':FixedModel(2000.),'prediction_mode':'direct'}
    p=predict_from_frame(high,f,s,a)
    assert p.metadata['source_cap_applied']
    assert np.dot(p.flux_Wm2,a)==pytest.approx(s.sum())


def test_nighttime_zero_and_bad_schema_fail_closed():
    f,s,a=toy_frame()
    model={'model':FixedModel(400.),'prediction_mode':'residual'}
    p=predict_from_frame(model,f,np.zeros_like(s),a)
    assert np.array_equal(p.flux_Wm2,np.zeros_like(a))
    bad=f.drop(columns=['sun_up'])
    with pytest.raises(ValueError,match='feature columns'):
        predict_from_frame(model,bad,s,a)


def test_persisted_model_rejects_feature_reordering(tmp_path):
    import joblib
    p=tmp_path/'test.joblib'
    joblib.dump({'model':FixedModel(1),'features':list(reversed(MODEL_FEATURES)),
                 'target':'multibounce_abs_Wm2'},p)
    with pytest.raises(ValueError,match='schema'):
        load_surrogate(p)


def test_scene_shape_rejection():
    f,s,a=toy_frame()
    bad_scene=toy_scene()
    with pytest.raises(ValueError,match='lengths'):
        feature_frame(bad_scene,np.array([1.]),np.array([1.,1.]),
                      np.array([1.,0.,0.]),{'temperature_2m':20.},np.array([.18,.18]))
