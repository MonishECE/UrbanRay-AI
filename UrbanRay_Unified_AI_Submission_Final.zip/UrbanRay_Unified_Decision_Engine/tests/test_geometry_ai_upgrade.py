"""Numerical, train/inference parity, and research-integrity regression tests."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT))
from geometry_features import build_geometry_graph, table_scene, augment_full_scene_table, GEOMETRY_FEATURES
from ai_inference import feature_frame, predict_from_frame, ENHANCED_MODEL_FEATURES
from train_geometry_ai import hotspot_capture
from observational_preflight import preflight

class ConstantModel:
    def __init__(self,value):self.value=value
    def predict(self, data):return np.full(len(data),self.value)

def scene():
    return {'center':np.array([[0.,0,10],[10,0,10],[15.,0,10]]),
            'normal':np.array([[1.,0,0],[-1.,0,0],[1.,0,0]]),
            'area':np.array([10.,20.,10.]),
            'kind':np.array(['wall','wall','wall']),
            'building_id':np.array(['a','b','b'])}

def weather():
    return {'direct_normal_irradiance_instant':500.,'diffuse_radiation_instant':100.,
            'temperature_2m':25.,'wind_speed_10m':3.}

def test_geom_graph_responds_to_actual_neighbor_albedo_and_sunlight():
    graph=build_geometry_graph(scene(),max_neighbors=3,radius_m=40)
    dark=graph.features([200,300,100],[.2,.3,.3])
    brighter=graph.features([200,300,100],[.2,.6,.3])
    assert graph.kernel[0,1]>0
    assert brighter[0,-1]>dark[0,-1]>0
    assert graph.features([0,0,0],[.3,.3,.3])[:, -1].sum()==0
    assert dark[0,0]==1 # one other building, two patches
    assert dark[0,1]==pytest.approx(10)
    with pytest.raises(ValueError,match='Nonphysical'):
        graph.features([-1,100,20],[.2,.3,.3])


def test_full_table_geometry_matches_live_feature_frame():
    s=scene();graph=build_geometry_graph(s,max_neighbors=3,radius_m=40)
    a=np.array([.2,.3,.3]);flux=np.array([200,300,100.]);sky=np.array([.8,.7,.8]);sun=np.array([.3,.4,.85])
    rows=[]
    for hour in ('2025-06-20T12:00Z','2025-06-20T13:00Z'):
        for face in range(3):
            rows.append({'time_utc':hour,'scenario':'dark_roof','face_id':face,
              'x_m':s['center'][face,0],'y_m':s['center'][face,1],'z_m':s['center'][face,2],
              'nx':s['normal'][face,0],'ny':s['normal'][face,1],'nz':s['normal'][face,2],
              'area_m2':s['area'][face],'kind':s['kind'][face],
              'building_id':s['building_id'][face],
              'source_flux_Wm2':flux[face],'albedo_assumed':a[face]})
    tab=pd.DataFrame(rows)
    enriched,_=augment_full_scene_table(tab,graph=graph)
    live=feature_frame(s,flux*s['area'],sky,sun,weather(),a,
           geometry_graph=graph,include_geometry=True)
    np.testing.assert_allclose(enriched.iloc[:3][list(GEOMETRY_FEATURES)],
                               live[list(GEOMETRY_FEATURES)],atol=1e-11)
    assert live.columns.tolist()==list(ENHANCED_MODEL_FEATURES)
    with pytest.raises(ValueError,match='Incomplete scene group'):
        augment_full_scene_table(tab.iloc[:-1],graph=graph)


def test_logged_hotspot_transform_restores_units_and_direct_floor():
    s=scene();a=np.array([.2,.3,.3]);flux=np.array([200.,300.,100.]);sky=np.array([.8,.7,.8])
    frame=feature_frame(s,flux*s['area'],sky,[.3,.4,.85],weather(),a,
           include_geometry=True)
    mdl={'model':ConstantModel(np.log1p(15.)), 'features':list(ENHANCED_MODEL_FEATURES),
         'prediction_mode':'residual','target_transform':'log1p'}
    prediction=predict_from_frame(mdl,frame,flux*s['area'],s['area'])
    np.testing.assert_allclose(prediction.flux_Wm2,flux*(1-a)+15.)
    assert prediction.metadata['geometry_features_used']
    with pytest.raises(ValueError,match='feature columns'):
        predict_from_frame(mdl,frame.iloc[:,:-1],flux*s['area'],s['area'])


def test_validation_flags_synthetic_weather_and_missing_inputs(tmp_path):
    pix=tmp_path/'real_export.csv';pix.write_text('real,export\n')
    no=preflight(None,pix)
    assert no['status'].startswith('NOT_READY')
    assert no['paired_AI_vs_Landsat_experiment_completed'] is False
    faces=tmp_path/'faces.csv';faces.write_text('test')
    (tmp_path/'audit.json').write_text('{"radiation_method":"compare", "weather_provenance_verified":false}')
    bad=preflight(faces,pix)
    assert 'not eligible' in bad['missing_or_invalid'][0]


def test_hotspot_metric_baseline_uses_direct_exposure_not_tie_breaking():
    # 24h*3 faces; most reflective face has least direct exposure.
    rows=[]
    for fid,baseline,extra in [(0,100.,1.),(1,50.,2.),(2,5.,20.)]:
        for hour in range(24):
            rows.append({'face_id':fid,'time_utc':f'2025-06-23T{hour:02d}:00Z',
                'kind':'wall','scenario':'dark_roof',
                'direct_plus_sky_abs_Wm2':baseline,'multibounce_abs_Wm2':baseline+extra})
    df=pd.DataFrame(rows)
    metric=hotspot_capture(df,df.direct_plus_sky_abs_Wm2.to_numpy(),k=1)
    assert metric['overlap']==0
    assert metric['captured_percent']==pytest.approx(5.)
